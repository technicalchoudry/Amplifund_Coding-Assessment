﻿namespace VideoStreaming.Models.Requests
{
    public class VideoUploadRequest
    {
        public IFormFile VideoFile { get; set; }
    }
}

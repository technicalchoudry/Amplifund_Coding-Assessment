﻿using VideoStreaming.Entities;

namespace VideoStreaming.Repositories.RepositoryInterfaces
{
    public interface IVideoRepository : IGenericRepository<Video>
    {
    }
}
